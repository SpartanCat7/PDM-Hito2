export default {
    PASS:"Password",
    USERNAME:"Username",
    DEFAULT_MARGIN_BURRON:50,
    TITLE_BUTTON:"INGRESAR"
}